#!/bin/ksh
for V in ${CPMAP_TEST_MEDIA:-/fs/sda0 /fs/sdb0 /net/mmx/fs/sda0 /net/mmx/fs/sdb0}; do
 if [ -s "$V/Custom/carplay_mu1367_p4521/install.sh" ]; then
  exec /bin/ksh "$V/Custom/carplay_mu1367_p4521/install.sh" "$V/Custom/carplay_maps_vc"
 fi
done
echo MU1367_P4521_MATCHING_SD_REQUIRED
exit 1
