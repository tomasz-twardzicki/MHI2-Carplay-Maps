#!/bin/ksh
/bin/ksh /mnt/app/eso/hmi/engdefs/scripts/mqb/cpmap_tune.sh low-card
